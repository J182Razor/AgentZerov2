#!/bin/bash
set -e

echo "🚀 Setting up God-Mode-OS..."

# Create necessary directories
mkdir -p exports/{campaign-packs,reports,digests}

# Copy env
cp .env.example .env

# Start services
echo "Starting Docker services..."
docker compose -f infra/docker-compose.yml up -d

# Wait for services
sleep 30

# Test health
if curl -f http://localhost:3000/health; then
  echo "✅ Service healthy"
else
  echo "❌ Service not healthy"
  exit 1
fi

# Import n8n workflows
echo "Importing n8n workflows..."
n8n import:workflow --input n8n/workflows/*.json

# Test database
psql $DATABASE_URL -c "SELECT 1;"

echo "✅ Setup complete!"
echo "🌐 n8n: http://localhost:5678"
echo "📊 Service: http://localhost:3000/metrics"
echo "📁 Exports: ./exports/"
