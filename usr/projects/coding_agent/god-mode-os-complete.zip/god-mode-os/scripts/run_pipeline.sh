#!/bin/bash

OFFER_ID=${1:-00000000-0000-0000-0000-000000000001}

echo "🔄 Running full pipeline for offer: $OFFER_ID"

curl -X POST http://localhost:3000/api/pipeline/dna-extraction \
  -H "Content-Type: application/json" \
  -d "{\"offerId\": \"$OFFER_ID\"}"

echo "🧬 DNA extraction complete"

curl -X POST http://localhost:3000/api/pipeline/hook-factory \
  -H "Content-Type: application/json" \
  -d "{\"offerId\": \"$OFFER_ID\"}"

echo "⚓ Hook factory complete"

curl -X POST http://localhost:3000/api/pipeline/campaign-generation \
  -H "Content-Type: application/json" \
  -d "{\"offerId\": \"$OFFER_ID\", \"packCount\": 3}"

echo "📦 Campaign packs generated! Check ./exports/campaign-packs/"
