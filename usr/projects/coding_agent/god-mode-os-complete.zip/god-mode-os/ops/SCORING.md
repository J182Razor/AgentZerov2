# Performance Scoring Framework

## Hook Scoring (0-100)

| Score Range | Description | Criteria |
|-------------|-------------|----------|
| 90-100 | Elite | Predicted >90, observed >85, 3+ validations, multi-platform success |
| 80-89 | Excellent | Predicted >80, observed >75, 2+ validations |
| 70-79 | Strong | Predicted >70, observed >65, 1+ validation |
| 60-69 | Good | Predicted >60, observed >55 |
| 50-59 | Average | Predicted >50, observed >45 |
| <50 | Weak | Needs improvement or retirement |

## DNA Pattern Scoring

**Predicted Score Calculation:**
```
Base Score = (frequency * 0.3) + (intensity * 0.4) + (engagement_avg * 0.3)
Confidence Multiplier = 0.5 + (evidence_count * 0.1)
Predicted Score = Base Score * Confidence Multiplier
```

**Observed Score Adjustment:**
- If observed > predicted +10: +5 bonus
- If observed < predicted -10: -10 penalty
- Update after 3+ observations

## Campaign Pack Quality

| Category | Excellent (A) | Good (B) | Needs Work (C) |
|----------|---------------|----------|----------------|
| Assets | 10+ diverse | 5-9 | <5 |
| Platforms | 4+ | 3 | 1-2 |
| Funnel | Complete | Partial | Linear |
| A/B Tests | 3+ | 2 | 0-1 |
| KPIs | Realistic + stretch | Realistic | Vague |
| Compliance | Perfect | Minor notes | Major flags |

## Workflow Success Metrics

- **Signal Harvester**: 50+ signals/day, <5% duplicates
- **DNA Extraction**: 5-15 patterns/day, >90% JSON valid
- **Hook Factory**: 20-50 hooks/day, avg predicted >70
- **Campaign Gen**: 1-3 packs/day, >80% quality A/B
- **Feedback Loop**: 100% performance processed

## Manual Override Rules

1. **Emergency Score Update**: If campaign >2x expected performance
2. **Pattern Blacklist**: Repeated failures (<30 observed after 5+ uses)
3. **Golden Hooks**: Manually promote to 'elite' status
4. **Compliance Lock**: Blocks deployment until fixed

## Review Cadence
- Daily: Top 10 hooks
- Weekly: Pattern score drift (>15 pts)
- Monthly: Full library audit
