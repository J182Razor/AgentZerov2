# Daily Standard Operating Procedure (SOP)

## Morning Routine (9:00 AM)

### 1. Review Feedback Loop Report
- Check `/exports/reports/YYYY-MM-DD-feedback.md`
- Review performance metrics from previous day
- Identify top-performing and underperforming assets
- Note any patterns or insights

### 2. Check System Health
```bash
curl http://localhost:3000/health
curl http://localhost:3000/metrics
```

### 3. Review Signal Digest
- Check `/exports/digests/digest-YYYY-MM-DD.md`
- Identify high-engagement signals
- Flag useful signals for processing
- Tag signals with relevant categories

### 4. Manual Signal Tagging (if needed)
```sql
UPDATE signals 
SET is_useful = true, tags = ARRAY['tag1', 'tag2']
WHERE id = 'signal-uuid';
```

## Midday Check (12:00 PM)

### 5. Monitor Workflow Status
- Check n8n dashboard: http://localhost:5678
- Verify all workflows are active
- Review any failed executions
- Check system logs:
```sql
SELECT * FROM system_logs 
WHERE log_level = 'error' 
AND created_at > NOW() - INTERVAL '24 hours'
ORDER BY created_at DESC;
```

### 6. Review Generated Content
- Check `/exports/campaign-packs/YYYY-MM-DD/`
- Review newly generated campaign packs
- Validate compliance and quality
- Flag any issues for manual review

## Afternoon Tasks (3:00 PM)

### 7. Performance Data Entry
- Manually input performance metrics if available
```sql
INSERT INTO performance (
  asset_id, hook_id, platform, metrics_json, 
  observed_score, date_start, date_end
) VALUES (
  'asset-uuid', 'hook-uuid', 'facebook',
  '{"impressions": 10000, "clicks": 500, "conversions": 50}',
  85.5, '2026-01-18', '2026-01-18'
);
```

### 8. Quality Assurance
- Review top 5 hooks from today:
```sql
SELECT * FROM hooks 
WHERE created_at::date = CURRENT_DATE 
ORDER BY predicted_score DESC 
LIMIT 5;
```
- Check for compliance issues
- Verify hook quality against QUALITY_BAR.md
- Approve or reject hooks:
```sql
UPDATE hooks SET status = 'approved' WHERE id = 'hook-uuid';
UPDATE hooks SET status = 'rejected' WHERE id = 'hook-uuid';
```

## End of Day (5:00 PM)

### 9. Daily Summary
- Generate daily metrics report:
```sql
SELECT 
  COUNT(*) FILTER (WHERE created_at::date = CURRENT_DATE) as signals_today,
  COUNT(*) FILTER (WHERE created_at::date = CURRENT_DATE) as hooks_today,
  COUNT(*) FILTER (WHERE created_at::date = CURRENT_DATE) as packs_today
FROM signals, hooks, campaign_packs;
```

### 10. Backup Check
- Verify database backup completed
- Check export files are saved
- Verify MinIO storage is accessible

### 11. Prepare for Tomorrow
- Review scheduled workflows for next day
- Flag any manual interventions needed
- Update task list for tomorrow

## Emergency Procedures

### If Workflow Fails
1. Check n8n logs
2. Check service logs: `docker logs godmode-service`
3. Check database connectivity
4. Restart workflow manually if needed
5. Document issue in system_logs

### If LLM API Fails
1. Check API key validity
2. Check rate limits
3. Switch to backup provider if configured
4. Queue failed requests for retry

### If Database Issues
1. Check PostgreSQL logs: `docker logs godmode-postgres`
2. Verify disk space
3. Check connection pool
4. Restart database if needed (last resort)

## Key Metrics to Track Daily

- **Signals Harvested**: Target 50-100/day
- **DNA Patterns Extracted**: Target 5-15/day
- **Hooks Generated**: Target 20-50/day
- **Campaign Packs Created**: Target 1-3/day
- **System Uptime**: Target 99.9%
- **LLM Success Rate**: Target >95%
- **Workflow Success Rate**: Target >98%

## Daily Checklist

- [ ] Review feedback report
- [ ] Check system health
- [ ] Review signal digest
- [ ] Monitor workflow status
- [ ] Review generated content
- [ ] Enter performance data
- [ ] Quality assurance check
- [ ] Generate daily summary
- [ ] Verify backups
- [ ] Update task list
