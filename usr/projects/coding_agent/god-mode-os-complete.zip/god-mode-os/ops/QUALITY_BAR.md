# Quality Bar Standards

## Hook Text Requirements

✅ **Must Have:**
- Platform-appropriate length
- Clear emotional trigger
- Specific benefit or pain point
- Actionable CTA
- Compliance-safe language

❌ **Never Allow:**
- Medical certainty claims
- Financial guarantees
- Vague/general statements
- Typos/grammar errors
- Overly salesy tone

## DNA Pattern Standards

✅ **High Quality:**
- 3+ specific evidence quotes
- Quantified frequency/intensity
- Clear emotional drivers
- Actionable marketing insight

## Campaign Pack Checklist

[ ] **Assets**: 8+ diverse asset types
[ ] **Platforms**: Multi-platform coverage
[ ] **Funnel**: Awareness→Conversion flow
[ ] **Targeting**: Specific demographics/behaviors
[ ] **A/B Tests**: 2+ meaningful tests
[ ] **KPIs**: Measurable targets
[ ] **Compliance**: All notes addressed
[ ] **Visuals**: Concrete image/video concepts

## LLM Output Validation

**JSON Only Rule:**
- No markdown code blocks
- No explanations/comments
- Valid schema compliance
- No hallucinations

**Retry Threshold:** 3 attempts max

## Human Review Triggers

🔴 **IMMEDIATE REVIEW:**
- Compliance flags
- Predicted score >95
- Observed score >90
- Novel pattern types

🟡 **WEEKLY REVIEW:**
- Avg predicted <60
- High variance (pred-obs >20)
- Low confidence (<70)

🟢 **AUTO-APPROVE:**
- Repeated success patterns
- Elite hooks (90+ score)
- Validated across platforms
