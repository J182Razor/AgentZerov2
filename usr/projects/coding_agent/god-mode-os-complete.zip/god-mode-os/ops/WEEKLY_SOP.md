# Weekly Standard Operating Procedure (SOP)

## Monday: Planning & Review

### 1. Weekly Performance Review
- Query 7-day performance trends
```sql
SELECT 
  platform, AVG(observed_score) as avg_score, COUNT(*) as count
FROM performance 
WHERE date_start >= NOW() - INTERVAL '7 days'
GROUP BY platform ORDER BY avg_score DESC;
```
- Identify winning patterns/hooks
- Document learnings in SCORING.md

### 2. Content Library Audit
- Review top-performing hooks:
```sql
SELECT * FROM v_top_performing_hooks LIMIT 20;
```
- Archive low-performers
- Promote winners to 'active' status

## Tuesday: Data Cleanup

### 3. Signal Cleanup
- Delete low-engagement signals (>7 days old)
```sql
DELETE FROM signals 
WHERE created_at < NOW() - INTERVAL '7 days' 
AND engagement_proxy < 10;
```

### 4. Pattern Validation
- Review DNA patterns with observed scores
- Flag discrepancies (predicted vs observed >20 points)
- Update pattern metadata with learnings

## Wednesday: Optimization

### 5. Hook Library Optimization
- Generate new hooks from top DNA patterns
```bash
curl -X POST http://localhost:3000/api/pipeline/hook-factory \
  -H "Content-Type: application/json" \
  -d '{"offerId": "00000000-0000-0000-0000-000000000001"}'
```

### 6. A/B Test Analysis
- Review campaign pack A/B test results
- Update hook scores based on performance

## Thursday: Expansion

### 7. New Signal Sources
- Add new RSS feeds or API sources
- Test signal harvester with new sources
- Update workflow_a_signal_harvester.json if needed

### 8. Persona Updates
- Review persona effectiveness
- Update personas table based on performance data

## Friday: Reporting & Planning

### 9. Weekly Report Generation
- Export weekly metrics to Markdown
- Summarize key learnings and recommendations
- Plan next week's priorities

### 10. System Maintenance
- Database vacuum/analyze
- Clear old exports (>30 days)
- Backup critical data
- Review resource usage

## Weekly Metrics Dashboard

| Metric | Target | Actual | Trend |
|--------|--------|--------|-------|
| Signals/week | 500+ | {{count}} | 📈/📉 |
| Patterns/week | 50+ | {{count}} | 📈/📉 |
| Hooks/week | 200+ | {{count}} | 📈/📉 |
| Packs/week | 10+ | {{count}} | 📈/📉 |
| Avg Score | >75 | {{avg}} | 📈/📉 |
| Workflow Success | >98% | {{pct}} | 📈/📉 |

## Escalation Criteria

- Workflow failure rate >5%
- LLM success rate <90%
- Disk usage >80% on any volume
- Database connection errors
- Export directory >10GB

## Weekly Checklist

- [ ] Weekly performance review
- [ ] Content library audit
- [ ] Data cleanup
- [ ] Pattern validation
- [ ] Hook library optimization
- [ ] A/B test analysis
- [ ] New signal sources
- [ ] Persona updates
- [ ] Weekly report
- [ ] System maintenance
