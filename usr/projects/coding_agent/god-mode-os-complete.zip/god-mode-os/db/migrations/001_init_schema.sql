-- God-Mode-OS Database Schema
-- Migration 001: Initial Schema Setup

-- Create n8n database for n8n service
CREATE DATABASE IF NOT EXISTS n8n;

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm"; -- For text search

-- Offers table: Core product/service offerings
CREATE TABLE IF NOT EXISTS offers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    offer_text TEXT NOT NULL,
    offer_url VARCHAR(500),
    price DECIMAL(10,2),
    target_customer TEXT,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_offers_name ON offers USING gin(name gin_trgm_ops);
CREATE INDEX idx_offers_created_at ON offers(created_at DESC);

-- Personas table: Target audience personas for each offer
CREATE TABLE IF NOT EXISTS personas (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    offer_id UUID NOT NULL REFERENCES offers(id) ON DELETE CASCADE,
    persona_name VARCHAR(255),
    persona_json JSONB NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_personas_offer_id ON personas(offer_id);
CREATE INDEX idx_personas_json ON personas USING gin(persona_json);

-- Signals table: Raw content signals from various sources
CREATE TABLE IF NOT EXISTS signals (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    source_type VARCHAR(50) NOT NULL, -- 'rss', 'reddit', 'youtube', 'twitter', etc.
    source_url VARCHAR(1000),
    source_id VARCHAR(255), -- External ID from source
    raw_text TEXT NOT NULL,
    engagement_proxy INTEGER DEFAULT 0, -- likes, upvotes, views, etc.
    tags TEXT[], -- Array of tags
    metadata JSONB DEFAULT '{}',
    content_hash VARCHAR(64) UNIQUE, -- SHA256 for deduplication
    is_processed BOOLEAN DEFAULT FALSE,
    is_useful BOOLEAN DEFAULT NULL, -- Manual flag
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    processed_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_signals_source_type ON signals(source_type);
CREATE INDEX idx_signals_content_hash ON signals(content_hash);
CREATE INDEX idx_signals_created_at ON signals(created_at DESC);
CREATE INDEX idx_signals_is_processed ON signals(is_processed);
CREATE INDEX idx_signals_tags ON signals USING gin(tags);
CREATE INDEX idx_signals_engagement ON signals(engagement_proxy DESC);

-- DNA Patterns table: Extracted patterns from signals
CREATE TABLE IF NOT EXISTS dna_patterns (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    offer_id UUID REFERENCES offers(id) ON DELETE SET NULL,
    pattern_type VARCHAR(50) NOT NULL, -- 'pain_point', 'desire', 'objection', 'trigger', etc.
    pattern_json JSONB NOT NULL,
    score_predicted DECIMAL(5,2) DEFAULT 0, -- 0-100 predicted effectiveness
    score_observed DECIMAL(5,2), -- Actual performance score
    confidence DECIMAL(5,2) DEFAULT 0, -- 0-100 confidence in pattern
    source_signal_ids UUID[], -- Array of signal IDs that contributed
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_dna_offer_id ON dna_patterns(offer_id);
CREATE INDEX idx_dna_pattern_type ON dna_patterns(pattern_type);
CREATE INDEX idx_dna_score_predicted ON dna_patterns(score_predicted DESC);
CREATE INDEX idx_dna_score_observed ON dna_patterns(score_observed DESC);
CREATE INDEX idx_dna_json ON dna_patterns USING gin(pattern_json);

-- Hooks table: Generated marketing hooks
CREATE TABLE IF NOT EXISTS hooks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    offer_id UUID REFERENCES offers(id) ON DELETE SET NULL,
    platform VARCHAR(50) NOT NULL, -- 'facebook', 'instagram', 'twitter', 'linkedin', 'email', etc.
    category VARCHAR(100), -- 'curiosity', 'urgency', 'social_proof', 'benefit', etc.
    hook_text TEXT NOT NULL,
    emotional_trigger VARCHAR(100), -- 'fear', 'desire', 'curiosity', 'belonging', etc.
    predicted_score DECIMAL(5,2) DEFAULT 0,
    observed_score DECIMAL(5,2),
    dedupe_hash VARCHAR(64) UNIQUE, -- SHA256 for deduplication
    dna_pattern_ids UUID[], -- Source DNA patterns
    metadata JSONB DEFAULT '{}',
    status VARCHAR(20) DEFAULT 'draft', -- 'draft', 'approved', 'rejected', 'active', 'archived'
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_hooks_offer_id ON hooks(offer_id);
CREATE INDEX idx_hooks_platform ON hooks(platform);
CREATE INDEX idx_hooks_category ON hooks(category);
CREATE INDEX idx_hooks_dedupe_hash ON hooks(dedupe_hash);
CREATE INDEX idx_hooks_predicted_score ON hooks(predicted_score DESC);
CREATE INDEX idx_hooks_status ON hooks(status);
CREATE INDEX idx_hooks_text_search ON hooks USING gin(hook_text gin_trgm_ops);

-- Campaign Packs table: Complete campaign packages
CREATE TABLE IF NOT EXISTS campaign_packs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    offer_id UUID REFERENCES offers(id) ON DELETE SET NULL,
    pack_name VARCHAR(255),
    pack_json JSONB NOT NULL,
    status VARCHAR(20) DEFAULT 'draft', -- 'draft', 'ready', 'deployed', 'archived'
    export_path VARCHAR(500),
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_campaign_packs_offer_id ON campaign_packs(offer_id);
CREATE INDEX idx_campaign_packs_status ON campaign_packs(status);
CREATE INDEX idx_campaign_packs_created_at ON campaign_packs(created_at DESC);

-- Assets table: Individual campaign assets
CREATE TABLE IF NOT EXISTS assets (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pack_id UUID NOT NULL REFERENCES campaign_packs(id) ON DELETE CASCADE,
    asset_type VARCHAR(50) NOT NULL, -- 'ad_copy', 'image', 'video', 'landing_page', etc.
    platform VARCHAR(50) NOT NULL,
    content_json JSONB NOT NULL,
    file_path VARCHAR(500),
    status VARCHAR(20) DEFAULT 'draft',
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_assets_pack_id ON assets(pack_id);
CREATE INDEX idx_assets_type ON assets(asset_type);
CREATE INDEX idx_assets_platform ON assets(platform);
CREATE INDEX idx_assets_status ON assets(status);

-- Performance table: Campaign performance metrics
CREATE TABLE IF NOT EXISTS performance (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    asset_id UUID REFERENCES assets(id) ON DELETE CASCADE,
    hook_id UUID REFERENCES hooks(id) ON DELETE SET NULL,
    platform VARCHAR(50) NOT NULL,
    metrics_json JSONB NOT NULL, -- impressions, clicks, conversions, cost, etc.
    observed_score DECIMAL(5,2), -- Calculated performance score
    date_start DATE NOT NULL,
    date_end DATE NOT NULL,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_performance_asset_id ON performance(asset_id);
CREATE INDEX idx_performance_hook_id ON performance(hook_id);
CREATE INDEX idx_performance_platform ON performance(platform);
CREATE INDEX idx_performance_date_range ON performance(date_start, date_end);
CREATE INDEX idx_performance_score ON performance(observed_score DESC);

-- System logs table for audit trail
CREATE TABLE IF NOT EXISTS system_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    log_type VARCHAR(50) NOT NULL, -- 'workflow', 'llm_call', 'validation', 'export', etc.
    log_level VARCHAR(20) DEFAULT 'info', -- 'debug', 'info', 'warning', 'error'
    message TEXT NOT NULL,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_system_logs_type ON system_logs(log_type);
CREATE INDEX idx_system_logs_level ON system_logs(log_level);
CREATE INDEX idx_system_logs_created_at ON system_logs(created_at DESC);

-- Trigger for updated_at timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_offers_updated_at BEFORE UPDATE ON offers FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_personas_updated_at BEFORE UPDATE ON personas FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_dna_patterns_updated_at BEFORE UPDATE ON dna_patterns FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_hooks_updated_at BEFORE UPDATE ON hooks FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_campaign_packs_updated_at BEFORE UPDATE ON campaign_packs FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_assets_updated_at BEFORE UPDATE ON assets FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_performance_updated_at BEFORE UPDATE ON performance FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Views for common queries
CREATE OR REPLACE VIEW v_top_performing_hooks AS
SELECT 
    h.id,
    h.hook_text,
    h.platform,
    h.category,
    h.emotional_trigger,
    AVG(p.observed_score) as avg_score,
    COUNT(p.id) as performance_count
FROM hooks h
LEFT JOIN performance p ON p.hook_id = h.id
WHERE h.status = 'active'
GROUP BY h.id, h.hook_text, h.platform, h.category, h.emotional_trigger
HAVING COUNT(p.id) > 0
ORDER BY avg_score DESC;

CREATE OR REPLACE VIEW v_recent_signals AS
SELECT 
    id,
    source_type,
    source_url,
    LEFT(raw_text, 200) as preview,
    engagement_proxy,
    tags,
    is_processed,
    is_useful,
    created_at
FROM signals
WHERE created_at > NOW() - INTERVAL '7 days'
ORDER BY created_at DESC;

