-- God-Mode-OS Seed Data
-- Migration 002: Demo Offer and Initial Data

-- Insert demo offer
INSERT INTO offers (id, name, offer_text, offer_url, price, target_customer, metadata)
VALUES (
    '00000000-0000-0000-0000-000000000001',
    'AI-Powered Content Automation Suite',
    'Transform your content creation workflow with our AI-powered automation suite. Generate high-quality content 10x faster with intelligent templates, automated workflows, and performance analytics.',
    'https://example.com/ai-content-suite',
    997.00,
    'Content creators, marketing agencies, and businesses looking to scale their content production without sacrificing quality',
    '{"features": ["AI content generation", "Automated workflows", "Performance analytics", "Multi-platform publishing"], "benefits": ["Save 20+ hours per week", "Increase content output by 10x", "Data-driven optimization", "Consistent brand voice"]}'
);

-- Insert demo personas
INSERT INTO personas (offer_id, persona_name, persona_json)
VALUES 
(
    '00000000-0000-0000-0000-000000000001',
    'Overwhelmed Content Creator',
    '{
        "name": "Sarah - The Overwhelmed Content Creator",
        "demographics": {"age": "28-35", "role": "Content Creator/Influencer", "income": "$50k-$100k"},
        "pain_points": [
            "Spending 40+ hours/week on content creation",
            "Struggling to maintain consistency across platforms",
            "Missing opportunities due to slow turnaround",
            "Burnout from repetitive tasks"
        ],
        "desires": [
            "More time for creative strategy",
            "Consistent posting schedule",
            "Better work-life balance",
            "Scale without hiring"
        ],
        "objections": [
            "Will AI content sound robotic?",
            "Is it worth the investment?",
            "Too complex to learn?"
        ],
        "triggers": ["time savings", "automation", "scalability", "quality"]
    }'
),
(
    '00000000-0000-0000-0000-000000000001',
    'Growth-Focused Agency Owner',
    '{
        "name": "Mike - The Growth-Focused Agency Owner",
        "demographics": {"age": "35-50", "role": "Marketing Agency Owner", "income": "$150k+"},
        "pain_points": [
            "High labor costs for content production",
            "Difficulty scaling client base",
            "Inconsistent quality from freelancers",
            "Tight margins on content services"
        ],
        "desires": [
            "Higher profit margins",
            "Ability to take on more clients",
            "Predictable quality",
            "Competitive advantage"
        ],
        "objections": [
            "Will clients accept AI-generated content?",
            "Integration with existing tools?",
            "ROI timeline?"
        ],
        "triggers": ["ROI", "scalability", "efficiency", "competitive edge"]
    }'
);

-- Insert sample signals (for testing)
INSERT INTO signals (source_type, source_url, source_id, raw_text, engagement_proxy, tags, content_hash, is_useful)
VALUES 
(
    'reddit',
    'https://reddit.com/r/marketing/comments/example1',
    'example1',
    'I spend 6 hours every day just creating social media posts. There has to be a better way. Anyone using AI tools that actually work?',
    156,
    ARRAY['pain_point', 'time_management', 'ai_tools'],
    encode(sha256('reddit_example1'::bytea), 'hex'),
    true
),
(
    'youtube',
    'https://youtube.com/watch?v=example2',
    'example2',
    'The biggest mistake I made was trying to do everything manually. Once I automated my content workflow, I 10x my output in half the time.',
    2341,
    ARRAY['success_story', 'automation', 'productivity'],
    encode(sha256('youtube_example2'::bytea), 'hex'),
    true
),
(
    'twitter',
    'https://twitter.com/user/status/example3',
    'example3',
    'Hot take: AI content tools are overhyped. They all produce generic garbage that needs heavy editing anyway.',
    89,
    ARRAY['objection', 'quality_concern', 'ai_skepticism'],
    encode(sha256('twitter_example3'::bytea), 'hex'),
    true
);

