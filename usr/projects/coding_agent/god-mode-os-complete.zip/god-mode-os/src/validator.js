import Ajv from 'ajv';
import addFormats from 'ajv-formats';
import logger from './logger.js';

const ajv = new Ajv({ allErrors: true, strict: false });
addFormats(ajv);

export function validateJSON(data, schema) {
  const validate = ajv.compile(schema);
  const valid = validate(data);
  
  return {
    valid,
    errors: validate.errors || []
  };
}

export async function repairJSON(jsonString, llmClient) {
  logger.info('Attempting JSON repair');
  
  const repairPrompt = `The following JSON is malformed. Please fix it and return only valid JSON:

${jsonString}

Return ONLY the fixed JSON, no explanations.`;
  
  const systemPrompt = 'You are a JSON repair expert. Fix malformed JSON and return only valid JSON.';
  
  try {
    const repaired = await llmClient.call(repairPrompt, systemPrompt, { jsonMode: true });
    const cleaned = llmClient.cleanJSONResponse(repaired);
    
    // Verify it's valid
    JSON.parse(cleaned);
    
    logger.info('JSON repair successful');
    return cleaned;
  } catch (error) {
    logger.error('JSON repair failed', { error: error.message });
    throw new Error('Failed to repair JSON: ' + error.message);
  }
}

export function loadSchema(schemaPath) {
  try {
    const schema = JSON.parse(fs.readFileSync(schemaPath, 'utf8'));
    return schema;
  } catch (error) {
    logger.error('Failed to load schema', { schemaPath, error: error.message });
    throw error;
  }
}

export default {
  validateJSON,
  repairJSON,
  loadSchema
};
