import OpenAI from 'openai';
import Anthropic from '@anthropic-ai/sdk';
import config from './config.js';
import logger from './logger.js';
import { validateJSON, repairJSON } from './validator.js';

class LLMClient {
  constructor() {
    this.provider = config.llm.provider;
    
    if (this.provider === 'openai' && config.llm.openai.apiKey) {
      this.openai = new OpenAI({ apiKey: config.llm.openai.apiKey });
    }
    
    if (this.provider === 'anthropic' && config.llm.anthropic.apiKey) {
      this.anthropic = new Anthropic({ apiKey: config.llm.anthropic.apiKey });
    }
  }

  async call(prompt, systemPrompt = '', options = {}) {
    const maxRetries = options.retries || config.llm.retries;
    const retryDelay = options.retryDelay || config.llm.retryDelay;
    
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        logger.info(`LLM call attempt ${attempt}/${maxRetries}`, { provider: this.provider });
        
        let response;
        if (this.provider === 'openai') {
          response = await this.callOpenAI(prompt, systemPrompt, options);
        } else if (this.provider === 'anthropic') {
          response = await this.callAnthropic(prompt, systemPrompt, options);
        } else {
          throw new Error(`Unsupported LLM provider: ${this.provider}`);
        }
        
        logger.info('LLM call successful', { attempt, provider: this.provider });
        return response;
      } catch (error) {
        logger.error(`LLM call failed (attempt ${attempt}/${maxRetries})`, { 
          error: error.message,
          provider: this.provider 
        });
        
        if (attempt === maxRetries) {
          throw error;
        }
        
        await this.sleep(retryDelay * attempt);
      }
    }
  }

  async callOpenAI(prompt, systemPrompt, options) {
    const messages = [];
    
    if (systemPrompt) {
      messages.push({ role: 'system', content: systemPrompt });
    }
    
    messages.push({ role: 'user', content: prompt });
    
    const response = await this.openai.chat.completions.create({
      model: options.model || config.llm.openai.model,
      messages,
      temperature: options.temperature || config.llm.openai.temperature,
      max_tokens: options.maxTokens || config.llm.openai.maxTokens,
      response_format: options.jsonMode ? { type: 'json_object' } : undefined
    });
    
    return response.choices[0].message.content;
  }

  async callAnthropic(prompt, systemPrompt, options) {
    const response = await this.anthropic.messages.create({
      model: options.model || config.llm.anthropic.model,
      max_tokens: options.maxTokens || config.llm.anthropic.maxTokens,
      temperature: options.temperature || config.llm.anthropic.temperature,
      system: systemPrompt || undefined,
      messages: [{ role: 'user', content: prompt }]
    });
    
    return response.content[0].text;
  }

  async callWithJSONValidation(prompt, systemPrompt, schema, options = {}) {
    const maxRetries = options.retries || config.llm.retries;
    
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        logger.info(`LLM JSON call attempt ${attempt}/${maxRetries}`);
        
        // Add JSON instruction to system prompt
        const jsonSystemPrompt = `${systemPrompt}\n\nIMPORTANT: You must respond with valid JSON only. No markdown, no explanations, just pure JSON.`;
        
        // Call LLM
        let response = await this.call(prompt, jsonSystemPrompt, { ...options, jsonMode: true });
        
        // Clean response (remove markdown if present)
        response = this.cleanJSONResponse(response);
        
        // Try to parse
        let parsed;
        try {
          parsed = JSON.parse(response);
        } catch (parseError) {
          logger.warn('JSON parse failed, attempting repair', { attempt });
          response = await repairJSON(response, this);
          parsed = JSON.parse(response);
        }
        
        // Validate against schema
        const validation = validateJSON(parsed, schema);
        if (!validation.valid) {
          logger.warn('JSON validation failed', { 
            attempt, 
            errors: validation.errors 
          });
          
          if (attempt < maxRetries) {
            // Add validation errors to next prompt
            const errorPrompt = `${prompt}\n\nPrevious attempt had validation errors: ${JSON.stringify(validation.errors)}\nPlease fix these issues and respond with valid JSON.`;
            prompt = errorPrompt;
            continue;
          }
          
          throw new Error(`JSON validation failed: ${JSON.stringify(validation.errors)}`);
        }
        
        logger.info('LLM JSON call successful', { attempt });
        return parsed;
        
      } catch (error) {
        logger.error(`LLM JSON call failed (attempt ${attempt}/${maxRetries})`, { 
          error: error.message 
        });
        
        if (attempt === maxRetries) {
          throw error;
        }
      }
    }
  }

  cleanJSONResponse(response) {
    // Remove markdown code blocks
    response = response.replace(/```json\s*/g, '').replace(/```\s*/g, '');
    // Remove leading/trailing whitespace
    response = response.trim();
    return response;
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

export default new LLMClient();
