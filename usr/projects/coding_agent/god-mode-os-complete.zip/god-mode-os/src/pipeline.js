import fs from 'fs/promises';
import path from 'path';
import crypto from 'crypto';
import config from './config.js';
import logger from './logger.js';
import db from './db.js';
import llm from './llm.js';
import exporter from './exporter.js';
import { validateJSON } from './validator.js';

async function loadPrompt(filename) {
  const filepath = path.join(config.prompts.basePath, filename);
  return await fs.readFile(filepath, 'utf8');
}

async function loadSchema(filename) {
  const filepath = path.join(config.schemas.basePath, filename);
  const content = await fs.readFile(filepath, 'utf8');
  return JSON.parse(content);
}

export async function runDNAExtraction(offerId = null) {
  logger.info('Starting DNA extraction pipeline', { offerId });
  try {
    const signals = await db.getRecentSignals(24);
    if (signals.length === 0) {
      logger.warn('No signals found for DNA extraction');
      return { success: false, message: 'No signals to process' };
    }
    logger.info(`Processing ${signals.length} signals for DNA extraction`);
    const promptTemplate = await loadPrompt('dna_extract.prompt.txt');
    const schema = await loadSchema('dna.schema.json');
    const signalData = signals.map(s => ({
      source: s.source_type, url: s.source_url, text: s.raw_text,
      engagement: s.engagement_proxy, tags: s.tags
    }));
    const prompt = `${promptTemplate}\n\nSIGNALS TO ANALYZE:\n${JSON.stringify(signalData, null, 2)}`;
    const dnaResult = await llm.callWithJSONValidation(
      prompt, 'You are an expert content strategist analyzing signals to extract DNA patterns.', schema
    );
    logger.info(`Extracted ${dnaResult.patterns.length} DNA patterns`);
    const savedPatterns = [];
    for (const pattern of dnaResult.patterns) {
      const sourceSignalIds = signals.slice(0, 5).map(s => s.id);
      const saved = await db.insertDNAPattern({
        offer_id: offerId, pattern_type: pattern.pattern_type, pattern_json: pattern,
        score_predicted: pattern.predicted_score, confidence: pattern.confidence,
        source_signal_ids: sourceSignalIds, metadata: { extraction_date: new Date().toISOString() }
      });
      if (saved) savedPatterns.push(saved);
    }
    for (const signal of signals) await db.markSignalProcessed(signal.id);
    await db.log('dna_extraction', 'info', `Extracted ${savedPatterns.length} DNA patterns`, {
      signal_count: signals.length, pattern_count: savedPatterns.length
    });
    return { success: true, patterns_extracted: savedPatterns.length, signals_processed: signals.length, patterns: savedPatterns };
  } catch (error) {
    logger.error('DNA extraction pipeline failed', { error: error.message, stack: error.stack });
    await db.log('dna_extraction', 'error', error.message, { offerId });
    throw error;
  }
}

export async function runHookFactory(offerId = null) {
  logger.info('Starting hook factory pipeline', { offerId });
  try {
    let offer = null;
    if (offerId) {
      offer = await db.getOffer(offerId);
      if (!offer) throw new Error(`Offer ${offerId} not found`);
    } else {
      const offers = await db.getOffers();
      offer = offers[0];
    }
    const dnaPatterns = await db.query(
      'SELECT * FROM dna_patterns WHERE offer_id = $1 OR offer_id IS NULL ORDER BY created_at DESC LIMIT 20',
      [offer.id]
    );
    if (dnaPatterns.rows.length === 0) {
      logger.warn('No DNA patterns found for hook generation');
      return { success: false, message: 'No DNA patterns to process' };
    }
    logger.info(`Generating hooks from ${dnaPatterns.rows.length} DNA patterns`);
    const promptTemplate = await loadPrompt('hook_factory.prompt.txt');
    const schema = await loadSchema('hooks.schema.json');
    const dnaData = dnaPatterns.rows.map(p => ({ id: p.id, type: p.pattern_type, pattern: p.pattern_json, score: p.score_predicted }));
    const offerData = { name: offer.name, description: offer.offer_text, price: offer.price, target: offer.target_customer };
    const prompt = `${promptTemplate}\n\nOFFER:\n${JSON.stringify(offerData, null, 2)}\n\nDNA PATTERNS:\n${JSON.stringify(dnaData, null, 2)}`;
    const hooksResult = await llm.callWithJSONValidation(
      prompt, 'You are an expert copywriter generating high-converting marketing hooks.', schema
    );
    logger.info(`Generated ${hooksResult.hooks.length} hooks`);
    const savedHooks = [];
    for (const hook of hooksResult.hooks) {
      const dedupeHash = crypto.createHash('sha256').update(hook.hook_text + hook.platform).digest('hex');
      const saved = await db.insertHook({
        offer_id: offer.id, platform: hook.platform, category: hook.category, hook_text: hook.hook_text,
        emotional_trigger: hook.emotional_trigger, predicted_score: hook.predicted_score, dedupe_hash: dedupeHash,
        dna_pattern_ids: hook.dna_pattern_ids || [], metadata: {
          variations: hook.variations, cta_suggestion: hook.cta_suggestion, reasoning: hook.reasoning, generation_date: new Date().toISOString()
        }
      });
      if (saved) savedHooks.push(saved);
    }
    await db.log('hook_factory', 'info', `Generated ${savedHooks.length} hooks`, {
      offer_id: offer.id, dna_pattern_count: dnaPatterns.rows.length, hook_count: savedHooks.length
    });
    return { success: true, hooks_generated: savedHooks.length, dna_patterns_used: dnaPatterns.rows.length, hooks: savedHooks };
  } catch (error) {
    logger.error('Hook factory pipeline failed', { error: error.message, stack: error.stack });
    await db.log('hook_factory', 'error', error.message, { offerId });
    throw error;
  }
}

export async function runCampaignGeneration(offerId = null, packCount = 3) {
  logger.info('Starting campaign generation pipeline', { offerId, packCount });
  try {
    let offer = null;
    if (offerId) {
      offer = await db.getOffer(offerId);
      if (!offer) throw new Error(`Offer ${offerId} not found`);
    } else {
      const offers = await db.getOffers();
      offer = offers[0];
    }
    const hooks = await db.query(
      'SELECT * FROM hooks WHERE offer_id = $1 AND status = $2 ORDER BY predicted_score DESC LIMIT 30',
      [offer.id, 'draft']
    );
    if (hooks.rows.length === 0) {
      logger.warn('No hooks found for campaign generation');
      return { success: false, message: 'No hooks available' };
    }
    const dnaPatterns = await db.query(
      'SELECT * FROM dna_patterns WHERE offer_id = $1 ORDER BY score_predicted DESC LIMIT 20',
      [offer.id]
    );
    logger.info(`Generating ${packCount} campaign packs from ${hooks.rows.length} hooks`);
    const promptTemplate = await loadPrompt('campaign_pack.prompt.txt');
    const schema = await loadSchema('campaign_pack.schema.json');
    const savedPacks = [];
    for (let i = 0; i < packCount; i++) {
      const hookData = hooks.rows.slice(i * 10, (i + 1) * 10).map(h => ({
        id: h.id, platform: h.platform, text: h.hook_text, category: h.category, trigger: h.emotional_trigger, score: h.predicted_score
      }));
      const dnaData = dnaPatterns.rows.map(p => ({ type: p.pattern_type, pattern: p.pattern_json }));
      const offerData = { name: offer.name, description: offer.offer_text, price: offer.price, target: offer.target_customer, metadata: offer.metadata };
      const prompt = `${promptTemplate}\n\nOFFER:\n${JSON.stringify(offerData, null, 2)}\n\nHOOKS:\n${JSON.stringify(hookData, null, 2)}\n\nDNA PATTERNS:\n${JSON.stringify(dnaData, null, 2)}`;
      const packResult = await llm.callWithJSONValidation(
        prompt, 'You are an expert campaign strategist creating complete campaign packs.', schema
      );
      logger.info(`Generated campaign pack: ${packResult.pack_name}`);
      const exportPath = await exporter.exportCampaignPack(packResult, offer.id);
      const saved = await db.insertCampaignPack({
        offer_id: offer.id, pack_name: packResult.pack_name, pack_json: packResult, export_path: exportPath,
        metadata: { generation_date: new Date().toISOString(), hook_count: hookData.length, asset_count: packResult.assets.length }
      });
      if (saved) savedPacks.push(saved);
    }
    await db.log('campaign_generation', 'info', `Generated ${savedPacks.length} campaign packs`, {
      offer_id: offer.id, pack_count: savedPacks.length
    });
    return { success: true, packs_generated: savedPacks.length, packs: savedPacks };
  } catch (error) {
    logger.error('Campaign generation pipeline failed', { error: error.message, stack: error.stack });
    await db.log('campaign_generation', 'error', error.message, { offerId });
    throw error;
  }
}

export async function runFeedbackLoop() {
  logger.info('Starting feedback loop pipeline');
  try {
    const performance = await db.getRecentPerformance(7);
    if (performance.length === 0) {
      logger.warn('No performance data found for feedback loop');
      return { success: false, message: 'No performance data available' };
    }
    logger.info(`Processing ${performance.length} performance entries`);
    const dnaUpdates = [];
    for (const perf of performance) {
      if (perf.hook_id) {
        const hook = await db.query('SELECT * FROM hooks WHERE id = $1', [perf.hook_id]);
        if (hook.rows.length > 0 && hook.rows[0].dna_pattern_ids) {
          for (const dnaId of hook.rows[0].dna_pattern_ids) {
            await db.updateDNAPatternScore(dnaId, perf.observed_score);
            dnaUpdates.push({ id: dnaId, score: perf.observed_score });
          }
        }
      }
    }
    logger.info(`Updated ${dnaUpdates.length} DNA pattern scores`);
    const date = new Date().toISOString().split('T')[0];
    const reportPath = await exporter.exportFeedbackReport(performance, dnaUpdates, date);
    await db.log('feedback_loop', 'info', `Processed ${performance.length} performance entries`, {
      performance_count: performance.length, dna_updates: dnaUpdates.length, report_path: reportPath
    });
    return { success: true, performance_processed: performance.length, dna_updates: dnaUpdates.length, report_path: reportPath };
  } catch (error) {
    logger.error('Feedback loop pipeline failed', { error: error.message, stack: error.stack });
    await db.log('feedback_loop', 'error', error.message);
    throw error;
  }
}
