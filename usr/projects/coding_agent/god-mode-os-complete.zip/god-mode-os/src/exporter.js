import fs from 'fs/promises';
import path from 'path';
import config from './config.js';
import logger from './logger.js';

class Exporter {
  constructor() {
    this.basePath = config.exports.basePath;
  }

  async ensureDirectory(dirPath) {
    try {
      await fs.mkdir(dirPath, { recursive: true });
    } catch (error) {
      logger.error('Failed to create directory', { dirPath, error: error.message });
      throw error;
    }
  }

  async exportCampaignPack(pack, offerId) {
    const date = new Date().toISOString().split('T')[0];
    const dirPath = path.join(this.basePath, 'campaign-packs', date);
    await this.ensureDirectory(dirPath);

    const filename = `pack-${pack.id || Date.now()}.json`;
    const filepath = path.join(dirPath, filename);

    try {
      await fs.writeFile(filepath, JSON.stringify(pack, null, 2), 'utf8');
      logger.info('Campaign pack exported', { filepath, packId: pack.id });
      return filepath;
    } catch (error) {
      logger.error('Failed to export campaign pack', { error: error.message });
      throw error;
    }
  }

  async exportDigest(signals, date) {
    const dirPath = path.join(this.basePath, 'digests');
    await this.ensureDirectory(dirPath);

    const filename = `digest-${date}.md`;
    const filepath = path.join(dirPath, filename);

    const content = this.generateDigestMarkdown(signals, date);

    try {
      await fs.writeFile(filepath, content, 'utf8');
      logger.info('Digest exported', { filepath, signalCount: signals.length });
      return filepath;
    } catch (error) {
      logger.error('Failed to export digest', { error: error.message });
      throw error;
    }
  }

  generateDigestMarkdown(signals, date) {
    let md = `# Daily Signal Digest - ${date}\n\n`;
    md += `**Total Signals:** ${signals.length}\n\n`;

    // Group by source type
    const grouped = signals.reduce((acc, signal) => {
      if (!acc[signal.source_type]) acc[signal.source_type] = [];
      acc[signal.source_type].push(signal);
      return acc;
    }, {});

    for (const [sourceType, items] of Object.entries(grouped)) {
      md += `## ${sourceType.toUpperCase()} (${items.length})\n\n`;
      
      // Sort by engagement
      items.sort((a, b) => (b.engagement_proxy || 0) - (a.engagement_proxy || 0));
      
      for (const signal of items.slice(0, 10)) { // Top 10 per source
        md += `### ${signal.source_url || 'No URL'}\n`;
        md += `**Engagement:** ${signal.engagement_proxy || 0}\n`;
        md += `**Tags:** ${(signal.tags || []).join(', ')}\n`;
        md += `**Content Preview:**\n${signal.raw_text.substring(0, 200)}...\n\n`;
        md += `---\n\n`;
      }
    }

    return md;
  }

  async exportFeedbackReport(performance, dnaUpdates, date) {
    const dirPath = path.join(this.basePath, 'reports');
    await this.ensureDirectory(dirPath);

    const filename = `${date}-feedback.md`;
    const filepath = path.join(dirPath, filename);

    const content = this.generateFeedbackMarkdown(performance, dnaUpdates, date);

    try {
      await fs.writeFile(filepath, content, 'utf8');
      logger.info('Feedback report exported', { filepath });
      return filepath;
    } catch (error) {
      logger.error('Failed to export feedback report', { error: error.message });
      throw error;
    }
  }

  generateFeedbackMarkdown(performance, dnaUpdates, date) {
    let md = `# Performance Feedback Report - ${date}\n\n`;
    
    md += `## Summary\n\n`;
    md += `- **Performance Entries:** ${performance.length}\n`;
    md += `- **DNA Patterns Updated:** ${dnaUpdates.length}\n\n`;

    if (performance.length > 0) {
      md += `## Top Performing Assets\n\n`;
      const sorted = [...performance].sort((a, b) => (b.observed_score || 0) - (a.observed_score || 0));
      
      for (const perf of sorted.slice(0, 5)) {
        md += `### Asset ID: ${perf.asset_id}\n`;
        md += `**Platform:** ${perf.platform}\n`;
        md += `**Score:** ${perf.observed_score}\n`;
        md += `**Metrics:** ${JSON.stringify(perf.metrics_json, null, 2)}\n\n`;
      }
    }

    if (dnaUpdates.length > 0) {
      md += `## DNA Pattern Updates\n\n`;
      for (const update of dnaUpdates) {
        md += `- Pattern ${update.id}: Predicted ${update.score_predicted} → Observed ${update.score_observed}\n`;
      }
      md += `\n`;
    }

    md += `## Next Actions\n\n`;
    md += `1. Review top-performing patterns and scale successful approaches\n`;
    md += `2. Analyze underperforming patterns and adjust strategy\n`;
    md += `3. Update hook library with validated patterns\n`;
    md += `4. Generate new campaign packs based on learnings\n`;

    return md;
  }

  async exportJSON(data, category, filename) {
    const dirPath = path.join(this.basePath, category);
    await this.ensureDirectory(dirPath);

    const filepath = path.join(dirPath, filename);

    try {
      await fs.writeFile(filepath, JSON.stringify(data, null, 2), 'utf8');
      logger.info('JSON exported', { filepath, category });
      return filepath;
    } catch (error) {
      logger.error('Failed to export JSON', { error: error.message });
      throw error;
    }
  }
}

export default new Exporter();
