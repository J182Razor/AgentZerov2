import express from 'express';
import config from './config.js';
import logger from './logger.js';
import db from './db.js';
import { runDNAExtraction, runHookFactory, runCampaignGeneration } from './pipeline.js';

const app = express();

app.use(express.json());

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Metrics endpoint
app.get('/metrics', async (req, res) => {
  try {
    const signals = await db.query('SELECT COUNT(*) as count FROM signals');
    const hooks = await db.query('SELECT COUNT(*) as count FROM hooks');
    const packs = await db.query('SELECT COUNT(*) as count FROM campaign_packs');
    
    res.json({
      signals: parseInt(signals.rows[0].count),
      hooks: parseInt(hooks.rows[0].count),
      campaign_packs: parseInt(packs.rows[0].count),
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    logger.error('Metrics error', { error: error.message });
    res.status(500).json({ error: 'Failed to fetch metrics' });
  }
});

// Manual pipeline triggers
app.post('/api/pipeline/dna-extraction', async (req, res) => {
  try {
    logger.info('Manual DNA extraction triggered');
    const result = await runDNAExtraction(req.body.offerId);
    res.json({ success: true, result });
  } catch (error) {
    logger.error('DNA extraction failed', { error: error.message });
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/pipeline/hook-factory', async (req, res) => {
  try {
    logger.info('Manual hook factory triggered');
    const result = await runHookFactory(req.body.offerId);
    res.json({ success: true, result });
  } catch (error) {
    logger.error('Hook factory failed', { error: error.message });
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/pipeline/campaign-generation', async (req, res) => {
  try {
    logger.info('Manual campaign generation triggered');
    const result = await runCampaignGeneration(req.body.offerId);
    res.json({ success: true, result });
  } catch (error) {
    logger.error('Campaign generation failed', { error: error.message });
    res.status(500).json({ error: error.message });
  }
});

// Get offers
app.get('/api/offers', async (req, res) => {
  try {
    const offers = await db.getOffers();
    res.json(offers);
  } catch (error) {
    logger.error('Failed to fetch offers', { error: error.message });
    res.status(500).json({ error: error.message });
  }
});

// Get signals
app.get('/api/signals', async (req, res) => {
  try {
    const hours = parseInt(req.query.hours || '24');
    const signals = await db.getRecentSignals(hours);
    res.json(signals);
  } catch (error) {
    logger.error('Failed to fetch signals', { error: error.message });
    res.status(500).json({ error: error.message });
  }
});

// Get top hooks
app.get('/api/hooks/top', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit || '10');
    const hooks = await db.getTopHooks(limit);
    res.json(hooks);
  } catch (error) {
    logger.error('Failed to fetch top hooks', { error: error.message });
    res.status(500).json({ error: error.message });
  }
});

// Error handler
app.use((err, req, res, next) => {
  logger.error('Unhandled error', { error: err.message, stack: err.stack });
  res.status(500).json({ error: 'Internal server error' });
});

// Start server
const PORT = config.server.port;
app.listen(PORT, () => {
  logger.info(`God-Mode-OS service started on port ${PORT}`);
  logger.info(`Environment: ${config.server.env}`);
  logger.info(`LLM Provider: ${config.llm.provider}`);
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  logger.info('SIGTERM received, shutting down gracefully');
  await db.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  logger.info('SIGINT received, shutting down gracefully');
  await db.close();
  process.exit(0);
});

export default app;
