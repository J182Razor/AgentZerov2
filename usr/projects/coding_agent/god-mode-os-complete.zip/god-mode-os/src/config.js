import dotenv from 'dotenv';
dotenv.config();

export const config = {
  database: {
    url: process.env.DATABASE_URL || 'postgresql://godmode:godmode_secret_2024@localhost:5432/godmode',
    pool: {
      max: 20,
      min: 5,
      idle: 10000
    }
  },
  redis: {
    url: process.env.REDIS_URL || 'redis://localhost:6379'
  },
  minio: {
    endpoint: process.env.MINIO_ENDPOINT || 'localhost',
    port: parseInt(process.env.MINIO_PORT || '9000'),
    useSSL: process.env.MINIO_USE_SSL === 'true',
    accessKey: process.env.MINIO_ACCESS_KEY || 'godmode',
    secretKey: process.env.MINIO_SECRET_KEY || 'godmode_minio_2024'
  },
  llm: {
    provider: process.env.LLM_PROVIDER || 'openai', // 'openai' or 'anthropic'
    openai: {
      apiKey: process.env.OPENAI_API_KEY,
      model: process.env.OPENAI_MODEL || 'gpt-4-turbo-preview',
      maxTokens: parseInt(process.env.OPENAI_MAX_TOKENS || '4000'),
      temperature: parseFloat(process.env.OPENAI_TEMPERATURE || '0.7')
    },
    anthropic: {
      apiKey: process.env.ANTHROPIC_API_KEY,
      model: process.env.ANTHROPIC_MODEL || 'claude-3-opus-20240229',
      maxTokens: parseInt(process.env.ANTHROPIC_MAX_TOKENS || '4000'),
      temperature: parseFloat(process.env.ANTHROPIC_TEMPERATURE || '0.7')
    },
    retries: parseInt(process.env.LLM_RETRIES || '3'),
    retryDelay: parseInt(process.env.LLM_RETRY_DELAY || '2000')
  },
  server: {
    port: parseInt(process.env.PORT || '3000'),
    env: process.env.NODE_ENV || 'development'
  },
  exports: {
    basePath: process.env.EXPORTS_PATH || '/app/exports'
  },
  prompts: {
    basePath: process.env.PROMPTS_PATH || '/app/prompts'
  },
  schemas: {
    basePath: process.env.SCHEMAS_PATH || '/app/schemas'
  }
};

export default config;
