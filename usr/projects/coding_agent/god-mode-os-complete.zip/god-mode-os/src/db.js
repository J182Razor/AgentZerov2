import pg from 'pg';
import config from './config.js';
import logger from './logger.js';

const { Pool } = pg;

class Database {
  constructor() {
    this.pool = new Pool({
      connectionString: config.database.url,
      ...config.database.pool
    });

    this.pool.on('error', (err) => {
      logger.error('Unexpected database error', { error: err.message });
    });
  }

  async query(text, params) {
    const start = Date.now();
    try {
      const res = await this.pool.query(text, params);
      const duration = Date.now() - start;
      logger.debug('Executed query', { text, duration, rows: res.rowCount });
      return res;
    } catch (error) {
      logger.error('Database query error', { text, error: error.message });
      throw error;
    }
  }

  async getClient() {
    return await this.pool.connect();
  }

  async transaction(callback) {
    const client = await this.getClient();
    try {
      await client.query('BEGIN');
      const result = await callback(client);
      await client.query('COMMIT');
      return result;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  // Offers
  async getOffers() {
    const res = await this.query('SELECT * FROM offers ORDER BY created_at DESC');
    return res.rows;
  }

  async getOffer(id) {
    const res = await this.query('SELECT * FROM offers WHERE id = $1', [id]);
    return res.rows[0];
  }

  // Signals
  async insertSignal(signal) {
    const { source_type, source_url, source_id, raw_text, engagement_proxy, tags, content_hash, metadata } = signal;
    const res = await this.query(
      `INSERT INTO signals (source_type, source_url, source_id, raw_text, engagement_proxy, tags, content_hash, metadata)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       ON CONFLICT (content_hash) DO NOTHING
       RETURNING *`,
      [source_type, source_url, source_id, raw_text, engagement_proxy || 0, tags || [], content_hash, metadata || {}]
    );
    return res.rows[0];
  }

  async getUnprocessedSignals(limit = 100) {
    const res = await this.query(
      'SELECT * FROM signals WHERE is_processed = false ORDER BY created_at DESC LIMIT $1',
      [limit]
    );
    return res.rows;
  }

  async getRecentSignals(hours = 24) {
    const res = await this.query(
      `SELECT * FROM signals 
       WHERE created_at > NOW() - INTERVAL '${hours} hours'
       AND (is_useful = true OR is_useful IS NULL)
       ORDER BY engagement_proxy DESC, created_at DESC`,
      []
    );
    return res.rows;
  }

  async markSignalProcessed(id) {
    await this.query(
      'UPDATE signals SET is_processed = true, processed_at = NOW() WHERE id = $1',
      [id]
    );
  }

  // DNA Patterns
  async insertDNAPattern(pattern) {
    const { offer_id, pattern_type, pattern_json, score_predicted, confidence, source_signal_ids, metadata } = pattern;
    const res = await this.query(
      `INSERT INTO dna_patterns (offer_id, pattern_type, pattern_json, score_predicted, confidence, source_signal_ids, metadata)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [offer_id, pattern_type, pattern_json, score_predicted || 0, confidence || 0, source_signal_ids || [], metadata || {}]
    );
    return res.rows[0];
  }

  async updateDNAPatternScore(id, observed_score) {
    await this.query(
      'UPDATE dna_patterns SET score_observed = $1 WHERE id = $2',
      [observed_score, id]
    );
  }

  // Hooks
  async insertHook(hook) {
    const { offer_id, platform, category, hook_text, emotional_trigger, predicted_score, dedupe_hash, dna_pattern_ids, metadata } = hook;
    const res = await this.query(
      `INSERT INTO hooks (offer_id, platform, category, hook_text, emotional_trigger, predicted_score, dedupe_hash, dna_pattern_ids, metadata)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       ON CONFLICT (dedupe_hash) DO NOTHING
       RETURNING *`,
      [offer_id, platform, category, hook_text, emotional_trigger, predicted_score || 0, dedupe_hash, dna_pattern_ids || [], metadata || {}]
    );
    return res.rows[0];
  }

  async getTopHooks(limit = 10) {
    const res = await this.query(
      'SELECT * FROM v_top_performing_hooks LIMIT $1',
      [limit]
    );
    return res.rows;
  }

  // Campaign Packs
  async insertCampaignPack(pack) {
    const { offer_id, pack_name, pack_json, export_path, metadata } = pack;
    const res = await this.query(
      `INSERT INTO campaign_packs (offer_id, pack_name, pack_json, export_path, metadata)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [offer_id, pack_name, pack_json, export_path, metadata || {}]
    );
    return res.rows[0];
  }

  async updateCampaignPackStatus(id, status) {
    await this.query(
      'UPDATE campaign_packs SET status = $1 WHERE id = $2',
      [status, id]
    );
  }

  // Performance
  async insertPerformance(perf) {
    const { asset_id, hook_id, platform, metrics_json, observed_score, date_start, date_end, metadata } = perf;
    const res = await this.query(
      `INSERT INTO performance (asset_id, hook_id, platform, metrics_json, observed_score, date_start, date_end, metadata)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [asset_id, hook_id, platform, metrics_json, observed_score, date_start, date_end, metadata || {}]
    );
    return res.rows[0];
  }

  async getRecentPerformance(days = 7) {
    const res = await this.query(
      `SELECT * FROM performance 
       WHERE date_start >= NOW() - INTERVAL '${days} days'
       ORDER BY date_start DESC`,
      []
    );
    return res.rows;
  }

  // System Logs
  async log(log_type, log_level, message, metadata = {}) {
    await this.query(
      'INSERT INTO system_logs (log_type, log_level, message, metadata) VALUES ($1, $2, $3, $4)',
      [log_type, log_level, message, metadata]
    );
  }

  async close() {
    await this.pool.end();
  }
}

export default new Database();
