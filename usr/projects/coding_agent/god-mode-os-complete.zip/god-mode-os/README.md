# 🚀 God-Mode-OS: Closed-Loop Content Intelligence Engine

[![Status](https://img.shields.io/badge/status-production%20ready-brightgreen.svg)](https://github.com)

**Local-first internal OS** that automates: Signal harvesting → DNA extraction → Hook factory → Campaign pack generation → Export → Performance feedback → Library updates.

## 🎯 What It Does

1. **Signal Harvester** (q4h): RSS/Reddit/YouTube → signals table
2. **Nightly Pipeline** (2am): Signals → DNA patterns → Hooks → Campaign packs → /exports/
3. **Feedback Loop** (9am): Performance data → Update DNA scores → Reports

## 📦 Tech Stack

| Component | Technology |
|-----------|------------|
| Orchestration | Docker Compose |
| Database | Postgres 15 |
| Storage | MinIO S3 |
| Workflows | n8n |
| Service | Node.js 20 + OpenAI/Anthropic |
| Validation | AJV JSON schemas + auto-repair |

## 🚀 Quick Start (5 minutes)

```bash
# 1. Clone & setup
cd /path/to/god-mode-os
cp .env.example .env
# Edit .env: Add OPENAI_API_KEY (or ANTHROPIC_API_KEY)

# 2. One-command setup
./scripts/setup.sh

# 3. Manual pipeline run (generates campaign packs)
./scripts/run_pipeline.sh

# 4. Access
# n8n: http://localhost:5678 (admin/godmode_n8n_2024)
# API: http://localhost:3000/metrics
# Exports: ./exports/campaign-packs/YYYY-MM-DD/
```

## 🛠 Full Setup

### Prerequisites
- Docker & Docker Compose
- Node.js 20 (for dev)

### Environment Variables (.env)
```
POSTGRES_PASSWORD=your_db_pass
MINIO_ROOT_USER=godmode
MINIO_ROOT_PASSWORD=your_minio_pass
N8N_USER=admin
N8N_PASSWORD=your_n8n_pass
LLM_PROVIDER=openai  # or anthropic
OPENAI_API_KEY=sk-...
PORT=3000
```

### Commands

| Action | Command |
|--------|---------|
| Full setup | `./scripts/setup.sh` |
| Run pipeline | `./scripts/run_pipeline.sh [offer-id]` |
| DNA only | `curl -X POST http://localhost:3000/api/pipeline/dna-extraction -d '{"offerId":"..."}'` |
| View metrics | `curl http://localhost:3000/metrics` |
| Health check | `curl http://localhost:3000/health` |
| n8n workflows | Auto-imported, active at localhost:5678 |

## 📁 Repository Structure
```
god-mode-os/
├── infra/docker-compose.yml          # Full stack orchestration
├── db/migrations/                    # Postgres schema + seed data
├── src/                              # Node.js service (LLM pipelines)
├── prompts/                          # LLM prompt templates
├── schemas/                          # JSON validation schemas
├── n8n/workflows/                    # 3 automated workflows
├── ops/                              # SOPs + quality docs
├── scripts/                          # setup.sh, run_pipeline.sh
├── exports/                          # Campaign packs, reports (auto)
└── README.md
```

## 🔄 Workflows (Auto-scheduled)

| Workflow | Schedule | Purpose |
|----------|----------|---------|
| A: Signal Harvester | q4h | RSS/Reddit → signals |
| B: Nightly Gen | 2am daily | DNA → Hooks → Packs |
| C: Feedback | 9am daily | Performance → DNA updates |

## 📊 Daily Operations
Follow `/ops/DAILY_SOP.md`:
- Review exports
- Enter performance data
- Quality assurance
- Monitor workflows

## 🔒 Security & Compliance
- LLM compliance guard (no guarantees)
- JSON-only outputs
- Rate limiting
- Structured logging
- Deduplication

## 🧪 Testing
```bash
# Test pipeline
./scripts/run_pipeline.sh

# Check exports
ls -la exports/campaign-packs/$(date +%Y-%m-%d)/

# View top hooks
curl http://localhost:3000/api/hooks/top
```

## 📈 Monitoring
- `/metrics`: Signal/hook/pack counts
- n8n dashboard: Workflow status
- Postgres: `system_logs` table
- Logs: `docker logs godmode-service`

## 🔧 Customization
1. Add RSS sources → workflow_a_signal_harvester.json
2. New prompts/schemas → /prompts/, /schemas/
3. Custom offers → `INSERT INTO offers...`
4. Switch LLM → .env LLM_PROVIDER

## 🎉 Success Metrics
- **50+ signals/day**
- **20+ hooks/day (avg score >70)**
- **1-3 campaign packs/day**
- **95%+ LLM success rate**

**God-Mode-OS is now LIVE!** 🚀
